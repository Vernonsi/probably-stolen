﻿#include <iostream>
#include <string>

using namespace std;

bool CheckLength(string str) // проверка на длину числа
{
	if (str.length() <= 10) return true;
	return false;
}

bool CheckDigitD(string str) // проверка на буквы и лишние символы
{
	int d = 0;
	int x = 0;
	int m = 0;
	if (str[0] == '-') m++;
	for (int i = 0; i < str.length() + 1; i++) {
		if (d >= 2) {
			return false;
		}
		if (isdigit(str[i])) x++;
		if (i != 0) {
			if (str[i] == '-') return false;
		}
		if (str[i] == '.') d++;
	}
	if (x == str.length() - d - m) return true;
	return false;
}

bool CheckBoolD(double s) // проверка уже существующего числа
{
	string str = to_string(s);
	if (CheckDigitD(str) && CheckLength(str)) return true;
	return false;
}

double CheckD(string what) { // проверка вводимого дейстительное числа
	string str;
	int d = 0;
	int i = 0;
	while (true) {

		cout << "input " << what << ": ";
		cin >> str;

		if(CheckDigitD(str) && CheckLength(str)) return stod(str);

		else {
			cout << "invalid input" << endl;
		}
	}
}
bool CheckDigitI(string str) // проверка вводимого целого числа
{
	int d = 0;

	for (int i = 0; i < str.length(); i++) {
		if (d == 1) {
			return false;
		}
		if (isdigit(str[i]) || str[i] == '.') {
			if (str[i] == '.') d++;
			continue;
		}
		else {
			return false;
		}
	}
	return true;
}

int Sign(string str) { // проверка на знак
	double str1 = stod(str);
	if (str1 == 0) return 0;
	if (str[0] == '-') return -1;
	return 1;
}

double CheckDPosit(string what) { // проверка на положительное действительное число
	string str;
	int d = 0;
	int i = 0;
	while (true) {

		cout << "input " << what << ": ";
		cin >> str;

		if (CheckDigitD(str) && CheckLength(str) && Sign(str) == 1) return stod(str);

		else {
			cout << "invalid input" << endl;
		}
	}
}
